package com.thaiopensource.relaxng.edit;

import java.util.List;

public interface Container {
  public List<Component> getComponents();
}
