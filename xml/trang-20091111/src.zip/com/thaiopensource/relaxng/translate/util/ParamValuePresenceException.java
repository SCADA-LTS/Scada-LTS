package com.thaiopensource.relaxng.translate.util;

public class ParamValuePresenceException extends Exception { }
