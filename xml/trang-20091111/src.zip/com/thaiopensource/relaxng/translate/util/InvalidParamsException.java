package com.thaiopensource.relaxng.translate.util;

public class InvalidParamsException extends Exception {
}
