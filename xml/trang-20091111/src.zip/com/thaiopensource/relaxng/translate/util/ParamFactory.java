package com.thaiopensource.relaxng.translate.util;

public interface ParamFactory {
  Param createParam(String name);
}
