package com.thaiopensource.datatype;

import org.relaxng.datatype.Datatype;

public interface Datatype2 extends Datatype {
  boolean alwaysValid();
}
